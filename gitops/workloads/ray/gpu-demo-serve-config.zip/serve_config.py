applications:
  - name: gpu_text_generation
    import_path: app:deployment
    route_prefix: /generate
    runtime_env:
      pip:
        - torch>=2.0.0
        - transformers>=4.30.0
        - accelerate
        - bitsandbytes
      working_dir: "."
    deployments:
      - name: TextGenerator
        num_replicas: 1
        ray_actor_options:
          num_gpus: 1
          num_cpus: 2
        user_config:
          model_id: "microsoft/DialoGPT-medium"
          max_length: 100
