from ray import serve
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch_neuronx
import os

@serve.deployment(
    ray_actor_options={"num_cpus": 1, "resources": {"neuron": 1}},
    autoscaling_config={"min_replicas": 1, "max_replicas": 2}
)
class NeuronTextGeneration:
    def __init__(self):
        model_id = os.getenv("MODEL_ID", "mistralai/Mistral-7B-Instruct-v0.3")
        print(f"Loading model: {model_id}")
        
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        
        # Load model for Neuron
        self.model = AutoModelForCausalLM.from_pretrained(
            model_id,
            torch_dtype="auto",
            low_cpu_mem_usage=True
        )
        
        print("Model loaded successfully on Neuron")
        
    async def __call__(self, request):
        prompt = request.get("prompt", "Hello, how are you?")
        max_tokens = int(request.get("max_tokens", 100))
        
        inputs = self.tokenizer(prompt, return_tensors="pt")
        
        with torch_neuronx.experimental.neuron_cores_context(start_nc=0, nc_count=1):
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_tokens,
                do_sample=True,
                temperature=0.7
            )
        
        generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        return {
            "prompt": prompt,
            "generated_text": generated_text,
            "model": model_id,
            "device": "neuron"
        }

deployment = NeuronTextGeneration.bind()
