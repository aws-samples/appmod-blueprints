from ray import serve
from vllm import LLM, SamplingParams
import os

@serve.deployment(
    ray_actor_options={"num_cpus": 1, "resources": {"neuron": 1}},
    autoscaling_config={"min_replicas": 1, "max_replicas": 2}
)
class NeuronTextGeneration:
    def __init__(self):
        model_id = os.getenv("MODEL_ID", "mistralai/Mistral-7B-Instruct-v0.3")
        print(f"Loading model: {model_id}")
        
        # Initialize vLLM with Neuron backend
        self.llm = LLM(
            model=model_id,
            tensor_parallel_size=2,  # trn1.2xlarge has 2 NeuronCores
            max_model_len=2048,
            device="neuron",
            trust_remote_code=True
        )
        
        print("vLLM model loaded successfully on Neuron")
        
    async def __call__(self, request):
        prompt = request.get("prompt", "Hello, how are you?")
        max_tokens = int(request.get("max_tokens", 100))
        
        # Create sampling parameters
        sampling_params = SamplingParams(
            temperature=0.7,
            top_p=0.9,
            max_tokens=max_tokens
        )
        
        # Generate text
        outputs = self.llm.generate([prompt], sampling_params)
        generated_text = outputs[0].outputs[0].text
        
        return {
            "prompt": prompt,
            "generated_text": generated_text,
            "model": os.getenv("MODEL_ID", "mistralai/Mistral-7B-Instruct-v0.3"),
            "device": "neuron"
        }

deployment = NeuronTextGeneration.bind()
