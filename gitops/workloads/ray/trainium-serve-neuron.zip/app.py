from ray import serve
from vllm import LLM, SamplingParams
import os
import time

@serve.deployment(
    ray_actor_options={"num_cpus": 1, "resources": {"neuron_cores": 2}},
    autoscaling_config={"min_replicas": 1, "max_replicas": 1}
)
class NeuronTextGeneration:
    def __init__(self):
        # Use Neuron-compiled model (TinyLlama doesn't have Neuron version)
        model_id = os.environ.get("MODEL_ID", "/mnt/models/models/gpt2-neuron")
        print(f"Loading model from: {model_id}")
        
        self.model_id = model_id
        self.llm = LLM(
            model=model_id,
            device="neuron",
            tensor_parallel_size=2,
            max_num_seqs=1,
            max_model_len=1024
        )
        print("vLLM model loaded successfully on Neuron")
        
    async def __call__(self, request):
        try:
            # Parse JSON request properly
            data = await request.json()
            prompt = data.get("prompt", "Hello, how are you?")
            max_tokens = int(data.get("max_tokens", 100))
            
            start_time = time.time()
            
            sampling_params = SamplingParams(
                temperature=0.7,
                top_p=0.9,
                max_tokens=max_tokens
            )
            
            outputs = self.llm.generate([prompt], sampling_params)
            generated_text = outputs[0].outputs[0].text
            
            inference_time = time.time() - start_time
            
            return {
                "prompt": prompt,
                "generated_text": generated_text,
                "inference_time_seconds": round(inference_time, 3),
                "device_used": "neuron",
                "model_device": "neuron",
                "model_path": self.model_id
            }
            
        except Exception as e:
            print(f"Error during inference: {str(e)}")
            return {
                "error": str(e),
                "device_used": "neuron",
                "model_path": self.model_id
            }

deployment = NeuronTextGeneration.bind()
