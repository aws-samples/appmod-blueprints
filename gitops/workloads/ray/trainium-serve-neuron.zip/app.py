from ray import serve
from vllm import LLM, SamplingParams

@serve.deployment(
    ray_actor_options={"num_cpus": 1, "resources": {"neuron_cores": 2}},
    autoscaling_config={"min_replicas": 1, "max_replicas": 1}
)
class NeuronTextGeneration:
    def __init__(self):
        # Model already copied by init container (runai-model-streamer)
        cache_model = "/tmp/neuron-compile-cache/mistral-7b-neuron"
        
        self.llm = LLM(
            model=cache_model,
            device="neuron",
            tensor_parallel_size=2,
            max_num_seqs=1,
            max_model_len=2048
        )
        print("vLLM model loaded successfully on Neuron")
        
    async def __call__(self, request):
        prompt = request.get("prompt", "Hello, how are you?")
        max_tokens = int(request.get("max_tokens", 100))
        
        sampling_params = SamplingParams(
            temperature=0.7,
            top_p=0.9,
            max_tokens=max_tokens
        )
        
        outputs = self.llm.generate([prompt], sampling_params)
        generated_text = outputs[0].outputs[0].text
        
        return {
            "prompt": prompt,
            "generated_text": generated_text,
            "model": "mistral-7b-neuron",
            "device": "neuron"
        }

deployment = NeuronTextGeneration.bind()
