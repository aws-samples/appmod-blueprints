from ray import serve
from transformers import AutoTokenizer, AutoModelForCausalLM
import os

@serve.deployment(
    ray_actor_options={"num_cpus": 1, "resources": {"neuron": 1}},
    autoscaling_config={"min_replicas": 1, "max_replicas": 2}
)
class NeuronTextGeneration:
    def __init__(self):
        model_id = os.getenv("MODEL_ID", "/mnt/models/models/mistral-7b-neuron")
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        self.model = AutoModelForCausalLM.from_pretrained(model_id)
        
    async def __call__(self, request):
        prompt = request.get("prompt", "Hello, how are you?")
        max_length = int(request.get("max_length", 100))
        
        inputs = self.tokenizer(prompt, return_tensors="pt")
        outputs = self.model.generate(**inputs, max_length=max_length)
        generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        return {
            "prompt": prompt,
            "generated_text": generated_text,
            "model": os.getenv("MODEL_ID"),
            "device": "neuron"
        }

deployment = NeuronTextGeneration.bind()
