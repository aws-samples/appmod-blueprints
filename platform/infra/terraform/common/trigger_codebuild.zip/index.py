import boto3
import os
      
codebuild = boto3.client('codebuild')
      
def handler(event, context):
    project_name = os.environ['CODEBUILD_PROJECT_NAME']
          
    response = codebuild.start_build(projectName=project_name)
          
    return {
        'statusCode': 200,
        'body': f"Build started: {response['build']['id']}"
    }
